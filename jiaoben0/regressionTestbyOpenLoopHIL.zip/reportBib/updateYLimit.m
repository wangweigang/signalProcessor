function yLimitiNew = updateYLimit(hdlOfPloti)
% make nice ylimit for plot

if nargin < 2,
    hdlOfPloti  = gca;
end

axes(hdlOfPloti);  
axis('tight');

xyLimit       = axis;
yLimitiNew(1) = xyLimit(3);
yLimitiNew(2) = xyLimit(4);

factor1 = 10^(1-floor(log10(xyLimit(3))));
factor2 = 10^(1-ceil(log10(xyLimit(4))));

yLim1     = floor(factor1*xyLimit(3)*0.8)/factor1;  % round it up
yLim2     = ceil(factor2*xyLimit(4)*1.1)/factor2;   % round it up

if yLim1 < xyLimit(3),  % update if a still lower limit is there
    yLimitiNew(1) = yLim1;
end
if yLim2 > xyLimit(4),  % update if a still higher limit is there
    yLimitiNew(2) = yLim2;
end

set(hdlOfPloti, 'YLim',yLimitiNew);
if xyLimit(1)<xyLimit(2),
    set(hdlOfPloti, 'XLim',[xyLimit(1) xyLimit(2)]);
end

end