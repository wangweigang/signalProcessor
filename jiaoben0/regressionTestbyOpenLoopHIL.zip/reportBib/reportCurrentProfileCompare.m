% generate vars for plot and a statistics 
% 
% I have to find a way to fix the period for picking the current profle
iStart = 3333;
iEnd   = 11111;
clf;
subplot(2,1,1);

plot(current(current_INDEX).time(iStart:iEnd), current(current_INDEX).signals(iStart:iEnd,1),'b-');
hold('on');
plot(current(current_INDEX).time(iStart:iEnd), current(current_INDEX).signals(iStart:iEnd,2),'r-');

grid('on');
xlabel('(a)');
ylabel(current(current_INDEX).signalName);
updateYLimit(gca);

subplot(2,1,2)
plot(current(current_INDEX).time(iStart:iEnd), current(current_INDEX).signals(iStart:iEnd,2)-current(current_INDEX).signals(iStart:iEnd,1),'k-');

grid('on');
xlabel({'time [s]';'(b)'});
ylabel(['Difference for ', current(current_INDEX).signalName]);
set(gcf, 'Color',[1 1 1]);
updateYLimit(gca);

% make some statistics for the difference

[maxValue maxIndex] = max( current(current_INDEX).signals(iStart:iEnd,2)-current(current_INDEX).signals(iStart:iEnd,1));
[minValue minIndex] = min( current(current_INDEX).signals(iStart:iEnd,2)-current(current_INDEX).signals(iStart:iEnd,1));
meanValue           = mean(current(current_INDEX).signals(iStart:iEnd,2)-current(current_INDEX).signals(iStart:iEnd,1));
stdValue            = std( current(current_INDEX).signals(iStart:iEnd,2)-current(current_INDEX).signals(iStart:iEnd,1));
if current(current_INDEX).signals(maxIndex,1)~=0,
   diffRelMax       = maxValue/abs(current(current_INDEX).signals(maxIndex,1));
else
   diffRelMax       = maxValue;
end
if current(current_INDEX).signals(minIndex,1)~=0,
   diffRelMin       = minValue/abs(current(current_INDEX).signals(minIndex,1));
else
   diffRelMin       = minValue;
end

% collect bad cases

if abs(diffRelMin)>0.1 || abs(diffRelMax)>0.1,
   currentAbnormalCnt                    = currentAbnormalCnt + 1;
   currentAbnormal{currentAbnormalCnt,1} = current(current_INDEX).signalName;
   currentAbnormal{currentAbnormalCnt,2} = num2str(diffRelMax);
   currentAbnormal{currentAbnormalCnt,3} = num2str(diffRelMin);
   currentAbnormal{currentAbnormalCnt,4} = num2str(stdValue);
   currentAbnormal{currentAbnormalCnt,5} = num2str(meanValue);
end

table_data={};

table_data{2,1} = 'Diff(abs)';
table_data{3,1} = 'Diff(rel)';

table_data{1,2} = 'Maximum/Time';
table_data{2,2} = [num2str(maxValue),'/',num2str(current(current_INDEX).time(maxIndex))];
table_data{3,2} = diffRelMax;

table_data{1,3} = 'Minimum/Time';
table_data{2,3} = [num2str(minValue),'/',num2str(current(current_INDEX).time(minIndex))];
table_data{3,3} = diffRelMin;

table_data{1,4} = 'STD';
table_data{2,4} = num2str(stdValue);

table_data{1,5} = 'Mean';
table_data{2,5} = num2str(meanValue);

