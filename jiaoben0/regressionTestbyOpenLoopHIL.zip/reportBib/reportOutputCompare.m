% generate plots and tables for output variables/signal

% reportOutputCompare

clf;
subplot(2,1,1)

doStairs = ~isempty(strfind(upper(outputVar(RegressionOutputVar_INDEX).signalName),'TSWO'))    || ...
           ~isempty(strfind(upper(outputVar(RegressionOutputVar_INDEX).signalName),'NVALVE'))  || ...
           ~isempty(strfind(upper(outputVar(RegressionOutputVar_INDEX).signalName),'NABSCYL')) || ...
           ~isempty(strfind(upper(outputVar(RegressionOutputVar_INDEX).signalName),'NACTREQ'));

if doStairs,
   stairs(outputVar(RegressionOutputVar_INDEX).time, outputVar(RegressionOutputVar_INDEX).signals(:,1),'b-');
   hold('on');
   stairs(outputVar(RegressionOutputVar_INDEX).time, outputVar(RegressionOutputVar_INDEX).signals(:,2),'r-');
else
   plot(outputVar(RegressionOutputVar_INDEX).time, outputVar(RegressionOutputVar_INDEX).signals(:,1),'b-');
   hold('on');
   plot(outputVar(RegressionOutputVar_INDEX).time, outputVar(RegressionOutputVar_INDEX).signals(:,2),'r-');
end

grid('on');
xlabel('(a)');
ylabel(outputVar(RegressionOutputVar_INDEX).signalName);
updateYLimit(gca);

subplot(2,1,2)
if doStairs,
    stairs(outputVar(RegressionOutputVar_INDEX).time, outputVar(RegressionOutputVar_INDEX).signals(:,2)-outputVar(RegressionOutputVar_INDEX).signals(:,1),'k-');
else
    plot(outputVar(RegressionOutputVar_INDEX).time, outputVar(RegressionOutputVar_INDEX).signals(:,2)-outputVar(RegressionOutputVar_INDEX).signals(:,1),'k-');
end
grid('on');
xlabel({'time [ms]';'(b)'});
ylabel(['Difference for ', outputVar(RegressionOutputVar_INDEX).signalName]);
set(gcf, 'Color',[1 1 1]);
updateYLimit(gca);

% make some statistics for the difference

[maxValue maxIndex] = max(outputVar(RegressionOutputVar_INDEX).signals(:,2)-outputVar(RegressionOutputVar_INDEX).signals(:,1));
[minValue minIndex] = min(outputVar(RegressionOutputVar_INDEX).signals(:,2)-outputVar(RegressionOutputVar_INDEX).signals(:,1));
meanValue           = mean(outputVar(RegressionOutputVar_INDEX).signals(:,2)-outputVar(RegressionOutputVar_INDEX).signals(:,1));
stdValue            = std(outputVar(RegressionOutputVar_INDEX).signals(:,2)-outputVar(RegressionOutputVar_INDEX).signals(:,1));
if outputVar(RegressionOutputVar_INDEX).signals(maxIndex,1)~=0,
   diffRelMax       = maxValue/abs(outputVar(RegressionOutputVar_INDEX).signals(maxIndex,1));
else
   diffRelMax       = maxValue;
end
if outputVar(RegressionOutputVar_INDEX).signals(minIndex,1)~=0,
   diffRelMin       = minValue/abs(outputVar(RegressionOutputVar_INDEX).signals(minIndex,1));
else
   diffRelMin       = minValue;
end

% collect bad cases

if abs(diffRelMin)>0.1 || abs(diffRelMax)>0.1,
   outputAbnormalCnt                   = outputAbnormalCnt + 1;
   outputAbnormal{outputAbnormalCnt,1} = outputVar(RegressionOutputVar_INDEX).signalName;
   outputAbnormal{outputAbnormalCnt,2} = num2str(diffRelMax);
   outputAbnormal{outputAbnormalCnt,3} = num2str(diffRelMin);
   outputAbnormal{outputAbnormalCnt,4} = num2str(stdValue);
   outputAbnormal{outputAbnormalCnt,5} = num2str(meanValue);
end

table_data={};

table_data{2,1} = 'Diff(abs)';
table_data{3,1} = 'Diff(rel)';

table_data{1,2} = 'Maximum/Time';
table_data{2,2} = [num2str(maxValue),'/',num2str(outputVar(RegressionOutputVar_INDEX).time(maxIndex))];
table_data{3,2} = diffRelMax;

table_data{1,3} = 'Minimum/Time';
table_data{2,3} = [num2str(minValue),'/',num2str(outputVar(RegressionOutputVar_INDEX).time(minIndex))];
table_data{3,3} = diffRelMin;

table_data{1,4} = 'STD';
table_data{2,4} = num2str(stdValue);

table_data{1,5} = 'Mean';
table_data{2,5} = num2str(meanValue);

%table_data{1,6} = 'Note';
%table_data{2,6} = '';

