% generate plots and tables for output variables/signal from driving
% sequence

clf;
subplot(1,1,1)

doStairs = ~isempty(strfind(upper(outputVar(drivingSeqOutputVar_INDEX).signalName),'TSWO'))    || ...
           ~isempty(strfind(upper(outputVar(drivingSeqOutputVar_INDEX).signalName),'NVALVE'))  || ...
           ~isempty(strfind(upper(outputVar(drivingSeqOutputVar_INDEX).signalName),'NABSCYL')) || ...
           ~isempty(strfind(upper(outputVar(drivingSeqOutputVar_INDEX).signalName),'NACTREQ'));

if doStairs,
   stairs(outputVar(drivingSeqOutputVar_INDEX).time, outputVar(drivingSeqOutputVar_INDEX).signals(:,1),'b-');
else
   plot(outputVar(drivingSeqOutputVar_INDEX).time, outputVar(drivingSeqOutputVar_INDEX).signals(:,1),'b-');
end

grid('on');
xlabel('time [ms]');
ylabel(outputVar(drivingSeqOutputVar_INDEX).signalName);
pos = get(gcf,'Position');
set(gcf, 'Position',[pos(1) pos(2) 560 420*0.7]);
updateYLimit(gca);

% build figure number
drivingSeqOutputFigCnt = drivingSeqOutputVar_INDEX + numOfInputVar;
