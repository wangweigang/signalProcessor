function shift = getSignalShift(curveTime1, curveTime2)

numOfSample1 = length(curveTime1);
numOfSample2 = length(curveTime2);

sampleTime = mean(diff(curveTime1(:,1)));

shift      = 0;

% find three points with differences of big small big
incCount   = 0;
pointMid   = 0; 
pointLeft  = -10; % relative to pointMid
pointRight = 10;  % relative to pointMid

while 1,
    diffi     = curveTime1(:,2)-interp1((curveTime2(:,1)+pointMid*sampleTime), curveTime2(:,2), curveTime1(:,1));
    stdMid    = std(diffi(find(~isnan(diffi))));
    diffi     = curveTime1(:,2)-interp1((curveTime2(:,1)+(pointMid+pointLeft)*sampleTime), curveTime2(:,2), curveTime1(:,1));
    stdLeft   = std(diffi(find(~isnan(diffi))));
    diffi     = curveTime1(:,2)-interp1((curveTime2(:,1)+(pointMid+pointRight)*sampleTime), curveTime2(:,2), curveTime1(:,1));
    stdRight  = std(diffi(find(~isnan(diffi))));
    % [stdLeft,stdMid,stdRight]
    if stdLeft>stdMid && stdMid<stdRight,
        break;
    elseif stdLeft>stdMid && stdMid>stdRight,
        pointMid = pointMid+pointRight;
    elseif stdLeft<stdMid && stdMid<stdRight,
        pointMid = pointMid+pointLeft;
    elseif stdLeft==stdMid,
        pointMid = 0.5*(pointMid+pointLeft + pointMid);
    elseif stdMid==stdRight,
        pointMid = 0.5*(pointMid + pointMid+pointRight);
    end
    
    aaa=0;
end


% use dividing-2 method to get the min

toleranceShift = 1.0e-6;
widthi         = 1.0e33;
pointLeft      = pointMid+pointLeft;
pointRight     = pointMid+pointRight;
pointRightOld  = pointRight;
pointRight     = pointMid;
pointLeftOld   = pointLeft;
iterCount      = 0;
while widthi>toleranceShift && iterCount<200,
    iterCount  = iterCount + 1;
    pointMid   = 0.5*(pointLeft +  pointRight);
    diffi      = curveTime1(:,2)-interp1((curveTime2(:,1)+pointMid*sampleTime), curveTime2(:,2), curveTime1(:,1));
    stdMid     = std(diffi(find(~isnan(diffi))));
    diffi      = curveTime1(:,2)-interp1((curveTime2(:,1)+pointLeft*sampleTime), curveTime2(:,2), curveTime1(:,1));
    stdLeft    = std(diffi(find(~isnan(diffi))));
    diffi      = curveTime1(:,2)-interp1((curveTime2(:,1)+pointRight*sampleTime), curveTime2(:,2), curveTime1(:,1));
    stdRight   = std(diffi(find(~isnan(diffi))));
    widthi = abs(pointRight-pointLeft);
    if stdLeft>stdMid && stdMid<stdRight,
        pointRight    = pointMid;
    elseif stdMid>stdRight,
        pointLeftOld = pointMid;
        pointLeft    = pointRight;
        pointRight   = pointRightOld;
    elseif stdMid>stdLeft,
        pointRightOld = pointMid;
        pointLeft     = pointLeftOld;
        pointRight    = pointMid;
    end
    % fprintf('\n %4i %9.4g %9.4g %9.4g %9.4g %9.4g %9.4g', iterCount, pointLeft, pointRight, widthi,stdLeft, stdMid, stdRight); 
    aaa=0;
end
fprintf('\n %4i %9.4g %9.4g %9.4g %9.4g %9.4g %9.4g\n', iterCount, pointLeft, pointRight, widthi,stdLeft, stdMid, stdRight); 

shift = pointMid*sampleTime;
 aaa=0;
end
