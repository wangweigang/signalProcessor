 % get the original input/out signal from the driving sequence

fileNameDrivingSequence    = evalin('base', 'fileNameDrivingSequence');

myMdfImport(fileNameDrivingSequence, 'workspace');

inputVar         = struct('signalName',{}, 'signals',{}, 'time',{});
outputVar        = struct('signalName',{}, 'signals',{}, 'time',{});

chnNo1           = '1';
chnNo2           = '2';
chnNo3           = '4';

inputVar(1).signalName   = 'rpm';
inputVar(1).description  = 'Engine speed';
inputVar(1).signals(:,1) = eval(['[evalin(''base'',', '''rpm_',          chnNo1,''')]']);
inputVar(1).time         = eval(['[evalin(''base'',', '''time_',         chnNo1,''')]']);

inputVar(2).signalName   = 'eClosAReqEC';
inputVar(2).description  = 'MV-close angle request (EVC)';
inputVar(2).signals(:,1) = eval(['[evalin(''base'',', '''eClosAReqEC_',  chnNo1,''')]']);
inputVar(2).time         = eval(['[evalin(''base'',', '''time_',         chnNo1,''')]']);

inputVar(3).signalName   = 'eOpenAReqLO';
inputVar(3).description  = 'MV-open angle request (LVO)';
inputVar(3).signals(:,1) = eval(['[evalin(''base'',', '''eOpenAReqLO_',  chnNo1,''')]']);
inputVar(3).time         = eval(['[evalin(''base'',', '''time_',         chnNo1,''')]']);

inputVar(4).signalName   = 'eOpenReqHB';
inputVar(4).description  = 'MV-open angle request (HB)';
inputVar(4).signals(:,1) = eval(['[evalin(''base'',', '''eOpenReqHB_',   chnNo1,''')]']);
inputVar(4).time         = eval(['[evalin(''base'',', '''time_',         chnNo1,''')]']);

inputVar(5).signalName   = 'nValveModeId';
inputVar(5).description  = 'SV mode ID';
inputVar(5).signals(:,1) = eval(['[evalin(''base'',', '''nValveModeId_', chnNo1,''')]']);
inputVar(5).time         = eval(['[evalin(''base'',', '''time_',         chnNo1,''')]']);

inputVar(6).signalName   = 'nAbsCylinderId';
inputVar(6).description  = 'Absolute cylinder ID';
tmp = eval(['[evalin(''base'',', '''nAbsCylinderId_',                    chnNo1,''')]']);
inputVar(6).signals(:,1) = tmp(1:44);
tmp = eval(['[evalin(''base'',', '''time_',                              chnNo1,''')]']);
inputVar(6).time         = tmp(1:44);

inputVar(7).signalName   = 'nActReqFreezTDC';
inputVar(7).description  = 'Freezing TDC';
inputVar(7).signals(:,1) = eval(['[evalin(''base'',', '''nActReqFreezTDC_',chnNo1,''')]']);
inputVar(7).time         = eval(['[evalin(''base'',', '''time_',           chnNo1,''')]']);

numOfInputVar = length(inputVar);


outputVar(1).signalName   = 'wOilTemp';
outputVar(1).description  = 'HPC oil temperature';
outputVar(1).signals(:,1) = eval(['[evalin(''base'',', '''wOilTemp_',     chnNo3,''')]']);
outputVar(1).time         = eval(['[evalin(''base'',', '''time_',         chnNo3,''')]']);

outputVar(2).signalName   = 'wCoilTemp';
outputVar(2).description  = 'Coil temperature';
outputVar(2).signals(:,1) = eval(['[evalin(''base'',', '''wCoilTemp_',    chnNo3,''')]']);
outputVar(2).time         = eval(['[evalin(''base'',', '''time_',         chnNo3,''')]']);

outputVar(3).signalName   = 'eStart';
outputVar(3).description  = 'electric start angle';
outputVar(3).signals(:,1) = eval(['[evalin(''base'',', '''eStartSX_',     chnNo1,''')]']);
outputVar(3).time         = eval(['[evalin(''base'',', '''time_',         chnNo1,''')]']);

outputVar(4).signalName   = 'eStartCmd1';
outputVar(4).description  = 'electric start angle (Cmd1)';
outputVar(4).signals(:,1) = eval(['[evalin(''base'',', '''eStartCmd1_',   chnNo1,''')]']);
outputVar(4).time         = eval(['[evalin(''base'',', '''time_',         chnNo1,''')]']);

outputVar(5).signalName   = 'eStartCmd2';
outputVar(5).description  = 'electric start angle (Cmd2)';
outputVar(5).signals(:,1) = eval(['[evalin(''base'',', '''eStartCmd2_',   chnNo1,''')]']);
outputVar(5).time         = eval(['[evalin(''base'',', '''time_',         chnNo1,''')]']);

outputVar(6).signalName   = 'eFinish';
outputVar(6).description  = 'Electric finish angle'; 
outputVar(6).signals(:,1) = eval(['[evalin(''base'',', '''eFinishSX_',    chnNo1,''')]']);
outputVar(6).time         = eval(['[evalin(''base'',', '''time_',         chnNo1,''')]']);

outputVar(7).signalName   = 'eFinishCmd1';
outputVar(7).description  = 'Electric finish angle (Cmd1)';
outputVar(7).signals(:,1) = eval(['[evalin(''base'',', '''eFinishCmd1_',  chnNo1,''')]']);
outputVar(7).time         = eval(['[evalin(''base'',', '''time_',         chnNo1,''')]']);

outputVar(8).signalName   = 'eFinishCmd2';
outputVar(8).description  = 'Electric finish angle (Cmd2)';
outputVar(8).signals(:,1) = eval(['[evalin(''base'',', '''eFinishCmd1_',  chnNo1,''')]']);
outputVar(8).time         = eval(['[evalin(''base'',', '''time_',         chnNo1,''')]']);

outputVar(9 ).signalName   = 'tSwOnMeas';
outputVar(9 ).description  = 'SV switch-on time (measurement)';
outputVar(9 ).signals(:,1) = eval(['[evalin(''base'',', '''tSwOnMeas_',   chnNo1,''')]']);
outputVar(9 ).time         = eval(['[evalin(''base'',', '''time_',        chnNo1,''')]']);

outputVar(10).signalName   = 'tSwOnSVSXCylCL0';
outputVar(10).description  = 'SV switch-on time (close-loop, cylinder 0)';
outputVar(10).signals(:,1) = eval(['[evalin(''base'',', '''tSwOnSVSXCylCL__ls_0_rs__',  chnNo1,''')]']);
outputVar(10).time         = eval(['[evalin(''base'',', '''time_',                     chnNo1,''')]']);

outputVar(11).signalName   = 'tSwOnSVSXCylCL1';
outputVar(11).description  = 'SV switch-on time (close-loop, cylinder 1)';
outputVar(11).signals(:,1) = eval(['[evalin(''base'',', '''tSwOnSVSXCylCL__ls_1_rs__',  chnNo1,''')]']);
outputVar(11).time         = eval(['[evalin(''base'',', '''time_',                     chnNo1,''')]']);

outputVar(12).signalName   = 'tSwOnSVSXCylCL2';
outputVar(12).description  = 'SV switch-on time (close-loop, cylinder 2)';
outputVar(12).signals(:,1) = eval(['[evalin(''base'',', '''tSwOnSVSXCylCL__ls_2_rs__',  chnNo1,''')]']);
outputVar(12).time         = eval(['[evalin(''base'',', '''time_',                     chnNo1,''')]']);

outputVar(13).signalName   = 'tSwOnSVSXCylCL3';
outputVar(13).description  = 'SV switch-on time (close-loop, cylinder 3)';
outputVar(13).signals(:,1) = eval(['[evalin(''base'',', '''tSwOnSVSXCylCL__ls_3_rs__',  chnNo1,''')]']);
outputVar(13).time         = eval(['[evalin(''base'',', '''time_',                     chnNo1,''')]']);

outputVar(14).signalName   = 'tSwOnLowPrecV0';
outputVar(14).description  = 'SV switch-on time (low precision, cylinder 0)';
outputVar(14).signals(:,1) = eval(['[evalin(''base'',', '''tSwOnLowPrecV__ls_0_rs__',   chnNo1,''')]']);
outputVar(14).time         = eval(['[evalin(''base'',', '''time_',                     chnNo1,''')]']);

outputVar(15).signalName   = 'tSwOnLowPrecV1';
outputVar(15).description  = 'SV switch-on time (low precision, cylinder 1)';
outputVar(15).signals(:,1) = eval(['[evalin(''base'',', '''tSwOnLowPrecV__ls_1_rs__',   chnNo1,''')]']);
outputVar(15).time         = eval(['[evalin(''base'',', '''time_',                     chnNo1,''')]']);

outputVar(16).signalName   = 'tSwOnLowPrecV2';
outputVar(16).description  = 'SV switch-on time (low precision, cylinder 2)';
outputVar(16).signals(:,1) = eval(['[evalin(''base'',', '''tSwOnLowPrecV__ls_2_rs__',   chnNo1,''')]']);
outputVar(16).time         = eval(['[evalin(''base'',', '''time_',                     chnNo1,''')]']);

outputVar(17).signalName   = 'tSwOnLowPrecV3';
outputVar(17).description  = 'SV switch-on time (low precision, cylinder 3)';
outputVar(17).signals(:,1) = eval(['[evalin(''base'',', '''tSwOnLowPrecV__ls_3_rs__',   chnNo1,''')]']);
outputVar(17).time         = eval(['[evalin(''base'',', '''time_',                     chnNo1,''')]']);

outputVar(18).signalName   = 'tSwOffMeas';
outputVar(18).description  = 'SV switch-off time (measurement)';
outputVar(18).signals(:,1) = eval(['[evalin(''base'',', '''tSwOffMeas_',               chnNo1,''')]']);
outputVar(18).time         = eval(['[evalin(''base'',', '''time_',                     chnNo1,''')]']);

outputVar(19).signalName   = 'tSwOffSVSXCylCL0';
outputVar(19).description  = 'SV switch-off (close-loop, cylinder 0)';
outputVar(19).signals(:,1) = eval(['[evalin(''base'',', '''tSwOffSVSXCylCL__ls_0_rs__', chnNo1,''')]']);
outputVar(19).time         = eval(['[evalin(''base'',', '''time_',                     chnNo1,''')]']);

outputVar(20).signalName   = 'tSwOffSVSXCylCL1';
outputVar(20).description  = 'SV switch-off (close-loop, cylinder 1)';
outputVar(20).signals(:,1) = eval(['[evalin(''base'',', '''tSwOffSVSXCylCL__ls_1_rs__', chnNo1,''')]']);
outputVar(20).time         = eval(['[evalin(''base'',', '''time_',                     chnNo1,''')]']);

outputVar(21).signalName   = 'tSwOffSVSXCylCL2';
outputVar(21).description  = 'SV switch-off (close-loop, cylinder 2)';
outputVar(21).signals(:,1) = eval(['[evalin(''base'',', '''tSwOffSVSXCylCL__ls_2_rs__', chnNo1,''')]']);
outputVar(21).time         = eval(['[evalin(''base'',', '''time_',                     chnNo1,''')]']);

outputVar(22).signalName   = 'tSwOffSVSXCylCL3';
outputVar(22).description  = 'SV switch-off (close-loop, cylinder 3)';
outputVar(22).signals(:,1) = eval(['[evalin(''base'',', '''tSwOffSVSXCylCL__ls_3_rs__', chnNo1,''')]']);
outputVar(22).time         = eval(['[evalin(''base'',', '''time_',                     chnNo1,''')]']);

% clear the vars just read 
clear('-regexp', '_');
