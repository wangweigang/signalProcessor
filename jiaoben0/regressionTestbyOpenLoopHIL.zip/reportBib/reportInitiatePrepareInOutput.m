% initialization and data preparation

% run preReport to get the two files from regrestion test
% say, fileNameLastRelease    = 'SVT_EVC_11p02build1.dat';
%      fileNameCurrentRelease = 'SVT_EVC_11p21build1.dat'
 
format short;

% get file names from workspace base
fileNameLastRelease    = evalin('base', 'fileNameLastRelease');
fileNameCurrentRelease = evalin('base', 'fileNameCurrentRelease');
lastBuild              = evalin('base', 'lastBuild');
currentBuild           = evalin('base', 'currentBuild');

% define a few vars

% file fileNameLastRelease and fileNameCurrentRelease

myMdfImport(fileNameLastRelease, 'workspace');

inputVar               = struct('signalName',{}, 'signals',{}, 'time',{});
outputVar              = struct('signalName',{}, 'signals',{}, 'time',{});
drivingSeqOutputFigCnt = 0;
% pointers used for chapter 3: compare request and realized
eClosAReqECIndex = 2;
eOpenAReqLOIndex = 3;
eOpenReqHBIndex  = 4;

eStartIndex      = 4;
eFinishIndex     = 7;
 
chnNo1           = '1';
chnNo2           = '2';
chnNo3           = '3';
chnNo4           = '4';

inputVar(1).signalName   = 'rpm';
inputVar(1).description  = 'Engine speed';
inputVar(1).signals(:,1) = eval(['[evalin(''base'',', '''rpm_',          chnNo1,''')]']);
inputVar(1).time         = eval(['[evalin(''base'',', '''time_',         chnNo1,''')]']);

inputVar(2).signalName   = 'iBatteryVolt';
inputVar(2).description  = 'Voltage on power stage';
inputVar(2).signals(:,1) = eval(['[evalin(''base'',', '''iBatteryVolt_', chnNo3,''')]']);
inputVar(2).time         = eval(['[evalin(''base'',', '''time_',         chnNo3,''')]']);

inputVar(3).signalName   = 'eClosAReqEC';
inputVar(3).description  = 'MV-close angle request (EVC)';
inputVar(3).signals(:,1) = eval(['[evalin(''base'',', '''eClosAReqEC_',  chnNo1,''')]']);
inputVar(3).time         = eval(['[evalin(''base'',', '''time_',         chnNo1,''')]']);

inputVar(4).signalName   = 'eOpenAReqLO';
inputVar(4).description  = 'MV-open angle request (LVO)';
inputVar(4).signals(:,1) = eval(['[evalin(''base'',', '''eOpenAReqLO_',  chnNo1,''')]']);
inputVar(4).time         = eval(['[evalin(''base'',', '''time_',         chnNo1,''')]']);

inputVar(5).signalName   = 'eOpenReqHB';
inputVar(5).description  = 'MV-open angle request (HB)';
inputVar(5).signals(:,1) = eval(['[evalin(''base'',', '''eOpenReqHB_',   chnNo1,''')]']);
inputVar(5).time         = eval(['[evalin(''base'',', '''time_',         chnNo1,''')]']);

inputVar(6).signalName   = 'nValveModeId';
inputVar(6).description  = 'SV mode ID';
inputVar(6).signals(:,1) = eval(['[evalin(''base'',', '''nValveModeId_', chnNo1,''')]']);
inputVar(6).time         = eval(['[evalin(''base'',', '''time_',         chnNo1,''')]']);

inputVar(7).signalName   = 'nAbsCylinderId';
inputVar(7).description  = 'Absolute cylinder ID';
tmp = eval(['[evalin(''base'',', '''nAbsCylinderId_',                    chnNo1,''')]']);
inputVar(7).signals(:,1) = tmp(1:44);
tmp = eval(['[evalin(''base'',', '''time_',                              chnNo1,''')]']);
inputVar(7).time         = tmp(1:44);

inputVar(8).signalName   = 'nActReqFreezTDC';
inputVar(8).description  = 'Freezing TDC';
inputVar(8).signals(:,1) = eval(['[evalin(''base'',', '''nActReqFreezTDC_',chnNo1,''')]']);
inputVar(8).time         = eval(['[evalin(''base'',', '''time_',           chnNo1,''')]']);

numOfInputVar = length(inputVar);

outputVar(1).signalName   = 'wOilTemp';
outputVar(1).description  = 'HPC oil temperature';
outputVar(1).signals(:,1) = eval(['[evalin(''base'',', '''wOilTemp_',     chnNo4,''')]']);
outputVar(1).time         = eval(['[evalin(''base'',', '''time_',         chnNo4,''')]']);

outputVar(2).signalName   = 'wCoilTemp';
outputVar(2).description  = 'Coil temperature';
outputVar(2).signals(:,1) = eval(['[evalin(''base'',', '''wCoilTemp_',    chnNo4,''')]']);
outputVar(2).time         = eval(['[evalin(''base'',', '''time_',         chnNo4,''')]']);

outputVar(3).signalName   = 'eStart';
outputVar(3).description  = 'electric start angle';
outputVar(3).signals(:,1) = eval(['[evalin(''base'',', '''eStartSX_',     chnNo1,''')]']);
outputVar(3).time         = eval(['[evalin(''base'',', '''time_',         chnNo1,''')]']);

outputVar(4).signalName   = 'eStartCmd1';
outputVar(4).description  = 'electric start angle (Cmd1)';
outputVar(4).signals(:,1) = eval(['[evalin(''base'',', '''eStartCmd1_',   chnNo1,''')]']);
outputVar(4).time         = eval(['[evalin(''base'',', '''time_',         chnNo1,''')]']);

outputVar(5).signalName   = 'eStartCmd2';
outputVar(5).description  = 'electric start angle (Cmd2)';
outputVar(5).signals(:,1) = eval(['[evalin(''base'',', '''eStartCmd2_',   chnNo1,''')]']);
outputVar(5).time         = eval(['[evalin(''base'',', '''time_',         chnNo1,''')]']);

outputVar(6).signalName   = 'eFinish';
outputVar(6).description  = 'Electric finish angle'; 
outputVar(6).signals(:,1) = eval(['[evalin(''base'',', '''eFinishSX_',    chnNo1,''')]']);
outputVar(6).time         = eval(['[evalin(''base'',', '''time_',         chnNo1,''')]']);

outputVar(7).signalName   = 'eFinishCmd1';
outputVar(7).description  = 'Electric finish angle (Cmd1)';
outputVar(7).signals(:,1) = eval(['[evalin(''base'',', '''eFinishCmd1_',  chnNo1,''')]']);
outputVar(7).time         = eval(['[evalin(''base'',', '''time_',         chnNo1,''')]']);

outputVar(8).signalName   = 'eFinishCmd2';
outputVar(8).description  = 'Electric finish angle (Cmd2)';
outputVar(8).signals(:,1) = eval(['[evalin(''base'',', '''eFinishCmd1_',  chnNo1,''')]']);
outputVar(8).time         = eval(['[evalin(''base'',', '''time_',         chnNo1,''')]']);

outputVar(9 ).signalName   = 'tSwOnMeas';
outputVar(9 ).description  = 'SV switch-on time (measurement)';
outputVar(9 ).signals(:,1) = eval(['[evalin(''base'',', '''tSwOnMeas_',   chnNo1,''')]']);
outputVar(9 ).time         = eval(['[evalin(''base'',', '''time_',        chnNo1,''')]']);

outputVar(10).signalName   = 'tSwOnSVSXCylCL0';
outputVar(10).description  = 'SV switch-on time (close-loop, cylinder 0)';
outputVar(10).signals(:,1) = eval(['[evalin(''base'',', '''tSwOnSVSXCylCL__ls_0_rs__', chnNo1,''')]']);
outputVar(10).time         = eval(['[evalin(''base'',', '''time_',                     chnNo1,''')]']);

outputVar(11).signalName   = 'tSwOnSVSXCylCL1';
outputVar(11).description  = 'SV switch-on time (close-loop, cylinder 1)';
outputVar(11).signals(:,1) = eval(['[evalin(''base'',', '''tSwOnSVSXCylCL__ls_1_rs__', chnNo1,''')]']);
outputVar(11).time         = eval(['[evalin(''base'',', '''time_',                     chnNo1,''')]']);

outputVar(12).signalName   = 'tSwOnSVSXCylCL2';
outputVar(12).description  = 'SV switch-on time (close-loop, cylinder 2)';
outputVar(12).signals(:,1) = eval(['[evalin(''base'',', '''tSwOnSVSXCylCL__ls_2_rs__', chnNo1,''')]']);
outputVar(12).time         = eval(['[evalin(''base'',', '''time_',                     chnNo1,''')]']);

outputVar(13).signalName   = 'tSwOnSVSXCylCL3';
outputVar(13).description  = 'SV switch-on time (close-loop, cylinder 3)';
outputVar(13).signals(:,1) = eval(['[evalin(''base'',', '''tSwOnSVSXCylCL__ls_3_rs__', chnNo1,''')]']);
outputVar(13).time         = eval(['[evalin(''base'',', '''time_',                     chnNo1,''')]']);

outputVar(14).signalName   = 'tSwOnLowPrecV0';
outputVar(14).description  = 'SV switch-on time (low precision, cylinder 0)';
outputVar(14).signals(:,1) = eval(['[evalin(''base'',', '''tSwOnLowPrecV__ls_0_rs__',  chnNo1,''')]']);
outputVar(14).time         = eval(['[evalin(''base'',', '''time_',                     chnNo1,''')]']);

outputVar(15).signalName   = 'tSwOnLowPrecV1';
outputVar(15).description  = 'SV switch-on time (low precision, cylinder 1)';
outputVar(15).signals(:,1) = eval(['[evalin(''base'',', '''tSwOnLowPrecV__ls_1_rs__',  chnNo1,''')]']);
outputVar(15).time         = eval(['[evalin(''base'',', '''time_',                     chnNo1,''')]']);

outputVar(16).signalName   = 'tSwOnLowPrecV2';
outputVar(16).description  = 'SV switch-on time (low precision, cylinder 2)';
outputVar(16).signals(:,1) = eval(['[evalin(''base'',', '''tSwOnLowPrecV__ls_2_rs__',  chnNo1,''')]']);
outputVar(16).time         = eval(['[evalin(''base'',', '''time_',                     chnNo1,''')]']);

outputVar(17).signalName   = 'tSwOnLowPrecV3';
outputVar(17).description  = 'SV switch-on time (low precision, cylinder 3)';
outputVar(17).signals(:,1) = eval(['[evalin(''base'',', '''tSwOnLowPrecV__ls_3_rs__',  chnNo1,''')]']);
outputVar(17).time         = eval(['[evalin(''base'',', '''time_',                     chnNo1,''')]']);

outputVar(18).signalName   = 'tSwOffMeas';
outputVar(18).description  = 'SV switch-off time (measurement)';
outputVar(18).signals(:,1) = eval(['[evalin(''base'',', '''tSwOffMeas_',               chnNo1,''')]']);
outputVar(18).time         = eval(['[evalin(''base'',', '''time_',                     chnNo1,''')]']);

outputVar(19).signalName   = 'tSwOffSVSXCylCL0';
outputVar(19).description  = 'SV switch-off (close-loop, cylinder 0)';
outputVar(19).signals(:,1) = eval(['[evalin(''base'',', '''tSwOffSVSXCylCL__ls_0_rs__', chnNo1,''')]']);
outputVar(19).time         = eval(['[evalin(''base'',', '''time_',                      chnNo1,''')]']);

outputVar(20).signalName   = 'tSwOffSVSXCylCL1';
outputVar(20).description  = 'SV switch-off (close-loop, cylinder 1)';
outputVar(20).signals(:,1) = eval(['[evalin(''base'',', '''tSwOffSVSXCylCL__ls_1_rs__', chnNo1,''')]']);
outputVar(20).time         = eval(['[evalin(''base'',', '''time_',                      chnNo1,''')]']);

outputVar(21).signalName   = 'tSwOffSVSXCylCL2';
outputVar(21).description  = 'SV switch-off (close-loop, cylinder 2)';
outputVar(21).signals(:,1) = eval(['[evalin(''base'',', '''tSwOffSVSXCylCL__ls_2_rs__', chnNo1,''')]']);
outputVar(21).time         = eval(['[evalin(''base'',', '''time_',                      chnNo1,''')]']);

outputVar(22).signalName   = 'tSwOffSVSXCylCL3';
outputVar(22).description  = 'SV switch-off (close-loop, cylinder 3)';
outputVar(22).signals(:,1) = eval(['[evalin(''base'',', '''tSwOffSVSXCylCL__ls_3_rs__', chnNo1,''')]']);
outputVar(22).time         = eval(['[evalin(''base'',', '''time_',                      chnNo1,''')]']);

% myBreak;

% clear the vars just read 
clear('-regexp', '_');

numOfOutputVar = length(outputVar);

myMdfImport(fileNameCurrentRelease, 'workspace');

timeCorrection = 0;

timei                    = eval(['[evalin(''base'',', '''time_',            chnNo4,''')]']);
inputVari                = eval(['[evalin(''base'',', '''rpm_',             chnNo4,''')]']);
timeCorrection = getSignalShift([inputVar(1).time,inputVar(1).signals(:,1)], [timei, inputVari]);
inputVar(1).signals(:,2) = interp1(timei+timeCorrection, inputVari, inputVar(1).time);

timei                    = eval(['[evalin(''base'',', '''time_',            chnNo3,''')]']);
inputVari                = eval(['[evalin(''base'',', '''iBatteryVolt_',    chnNo3,''')]']);
inputVar(2).signals(:,2) = interp1(timei+timeCorrection, inputVari, inputVar(2).time);

timei                    = eval(['[evalin(''base'',', '''time_',            chnNo4,''')]']);
inputVari                = eval(['[evalin(''base'',', '''eClosAReqEC_',     chnNo4,''')]']);
inputVar(3).signals(:,2) = interp1(timei+timeCorrection, inputVari, inputVar(3).time);

inputVari                = eval(['[evalin(''base'',', '''eOpenAReqLO_',     chnNo4,''')]']);
inputVar(4).signals(:,2) = interp1(timei+timeCorrection, inputVari, inputVar(4).time);

inputVari                = eval(['[evalin(''base'',', '''eOpenReqHB_',      chnNo4,''')]']);
inputVar(5).signals(:,2) = interp1(timei+timeCorrection, inputVari, inputVar(5).time);

inputVari                = eval(['[evalin(''base'',', '''nValveModeId_',    chnNo4,''')]']);
inputVar(6).signals(:,2) = interp1(timei+timeCorrection, inputVari, inputVar(6).time, 'nearest');

inputVari                = eval(['[evalin(''base'',', '''nAbsCylinderId_',  chnNo4,''')]']);
inputVar(7).signals(:,2) = interp1(timei+timeCorrection, inputVari, inputVar(7).time, 'nearest'); 

inputVari                = eval(['[evalin(''base'',', '''nActReqFreezTDC_', chnNo4,''')]']);
inputVar(8).signals(:,2) = interp1(timei+timeCorrection, inputVari, inputVar(8).time, 'nearest');


timei                     = eval(['[evalin(''base'',', '''time_',            chnNo2,''')]']);
outputVari                = eval(['[evalin(''base'',', '''wOilTemp_',        chnNo2,''')]']);
outputVar(1).signals(:,2) = interp1(timei+timeCorrection, outputVari, outputVar(1).time);

outputVari                = eval(['[evalin(''base'',', '''wCoilTemp_',       chnNo2,''')]']);
outputVar(2).signals(:,2) = interp1(timei+timeCorrection, outputVari, outputVar(2).time);

timei                     = eval(['[evalin(''base'',', '''time_',            chnNo4,''')]']);
outputVari                = eval(['[evalin(''base'',', '''eStartSX_',        chnNo4,''')]']);
outputVar(3).signals(:,2) = interp1(timei+timeCorrection, outputVari, outputVar(3).time);

outputVari                = eval(['[evalin(''base'',', '''eStartCmd1_',      chnNo4,''')]']);
outputVar(4).signals(:,2) = interp1(timei+timeCorrection, outputVari, outputVar(4).time);

outputVari                = eval(['[evalin(''base'',', '''eStartCmd2_',      chnNo4,''')]']);
outputVar(5).signals(:,2) = interp1(timei+timeCorrection, outputVari, outputVar(5).time);

outputVari                = eval(['[evalin(''base'',', '''eFinishSX_',       chnNo4,''')]']);
outputVar(6).signals(:,2) = interp1(timei+timeCorrection, outputVari, outputVar(6).time);

outputVari                = eval(['[evalin(''base'',', '''eFinishCmd1_',     chnNo4,''')]']);
outputVar(7).signals(:,2) = interp1(timei+timeCorrection, outputVari, outputVar(7).time);

outputVari                = eval(['[evalin(''base'',', '''eFinishCmd2_',     chnNo4,''')]']);
outputVar(8).signals(:,2) = interp1(timei+timeCorrection, outputVari, outputVar(8).time);

outputVari                 = eval(['[evalin(''base'',', '''tSwOnMeas_',      chnNo4,''')]']);
outputVar(9 ).signals(:,2) = interp1(timei+timeCorrection, outputVari, outputVar(9 ).time);

outputVari                 = eval(['[evalin(''base'',', '''tSwOnSVSXCylCL__ls_0_rs__',  chnNo4,''')]']);
outputVar(10).signals(:,2) = interp1(timei+timeCorrection, outputVari, outputVar(10).time);

outputVari                 = eval(['[evalin(''base'',', '''tSwOnSVSXCylCL__ls_1_rs__',  chnNo4,''')]']);
outputVar(11).signals(:,2) = interp1(timei+timeCorrection, outputVari, outputVar(11).time);

outputVari                 = eval(['[evalin(''base'',', '''tSwOnSVSXCylCL__ls_2_rs__',  chnNo4,''')]']);
outputVar(12).signals(:,2) = interp1(timei+timeCorrection, outputVari, outputVar(12).time);

outputVari                 = eval(['[evalin(''base'',', '''tSwOnSVSXCylCL__ls_3_rs__',  chnNo4,''')]']);
outputVar(13).signals(:,2) = interp1(timei+timeCorrection, outputVari, outputVar(13).time);

outputVari                 = eval(['[evalin(''base'',', '''tSwOnLowPrecV__ls_0_rs__',   chnNo4,''')]']);
outputVar(14).signals(:,2) = interp1(timei+timeCorrection, outputVari, outputVar(14).time);

outputVari                 = eval(['[evalin(''base'',', '''tSwOnLowPrecV__ls_1_rs__',   chnNo4,''')]']);
outputVar(15).signals(:,2) = interp1(timei+timeCorrection, outputVari, outputVar(15).time);

outputVari                 = eval(['[evalin(''base'',', '''tSwOnLowPrecV__ls_2_rs__',   chnNo4,''')]']);
outputVar(16).signals(:,2) = interp1(timei, outputVari, outputVar(16).time);

outputVari                 = eval(['[evalin(''base'',', '''tSwOnLowPrecV__ls_3_rs__',   chnNo4,''')]']);
outputVar(17).signals(:,2) = interp1(timei+timeCorrection, outputVari, outputVar(17).time);

outputVari                 = eval(['[evalin(''base'',', '''tSwOffMeas_',               chnNo4,''')]']);
outputVar(18).signals(:,2) = interp1(timei+timeCorrection, outputVari, outputVar(18).time);

outputVari                 = eval(['[evalin(''base'',', '''tSwOffSVSXCylCL__ls_0_rs__', chnNo4,''')]']);
outputVar(19).signals(:,2) = interp1(timei+timeCorrection, outputVari, outputVar(19).time);

outputVari                 = eval(['[evalin(''base'',', '''tSwOffSVSXCylCL__ls_1_rs__', chnNo4,''')]']);
outputVar(20).signals(:,2) = interp1(timei+timeCorrection, outputVari, outputVar(20).time);

outputVari                 = eval(['[evalin(''base'',', '''tSwOffSVSXCylCL__ls_2_rs__', chnNo4,''')]']);
outputVar(21).signals(:,2) = interp1(timei+timeCorrection, outputVari, outputVar(21).time);

outputVari                 = eval(['[evalin(''base'',', '''tSwOffSVSXCylCL__ls_3_rs__', chnNo4,''')]']);
outputVar(22).signals(:,2) = interp1(timei+timeCorrection, outputVari, outputVar(22).time);

clear('-regexp', '_');

% layout table contents
tableDataLayout = {};

tableDataLayout{1,1} = 'No';
tableDataLayout{1,2} = 'Item';
tableDataLayout{1,3} = 'Description';

tableDataLayout{2,1} = '1';
tableDataLayout{2,2} = 'ECU';
tableDataLayout{2,3} = ' ';

tableDataLayout{3,1} = '2';
tableDataLayout{3,2} = 'Software';
tableDataLayout{3,3} = {lastBuild;currentBuild};

tableDataLayout{4,1} = '3';
tableDataLayout{4,2} = 'Calibration';
tableDataLayout{4,3} = ' ';

tableDataLayout{5,1} = '4';
tableDataLayout{5,2} = 'SV layout';
tableDataLayout{5,3} = 'fast/slow/nom/stuck-mid';


% setup text element

%Evaluate this string in the base workspace

drivingSequence = {
'Ignition on'; 
'start recordings for normal variables (by INCA) and SV currents'; 
'Engine start'; 
'idle in neutral gear: 10 second'; 
'pedal depressed and releases quickly 3 times'; 
'back to idle: 5 second'; 
'engage 1st gear, accelerate to 20 km/h'; 
'engage 2nd gear, accelerate to 50 km/h'; 
'engage 3rd gear, accelerate to 80 km/h'; 
'engage 4th gear, accelerate to 120 km/h'; 
'stop the vehicle and keep the engine to run at idle for 10 second'; 
'save all recordings'
};

inputSignalList = cell(numOfInputVar,1);
for i = 1:numOfInputVar
    inputSignalList{i} = [inputVar(i).description, ': ', inputVar(i).signalName];
end


% inputSignalList = {
% ['Engine speed: ',                                                          'rpm'];...
% ['Value of the voltage on the power stage: ',                               'iBatteryVolt'];...
% ['Cylinder in expansion phase (90�CA after TDC): ',                         'nAbsCylinderId'];...
% ['Cylinder to be programmed: ',                                             'nCylSelectionId'];...
% ['Mechanical Valve Closing Angle of a cylinder in Early Closing Mode: ',    'eClosAReqEC'];...
% ['Mechanical Valve Opening Angle of a cylinder in Late Opening Mode: ',     'eOpenAReqLO'];...
% ['Mechanical valve opening angle of a cylinder in Hybrid Actuation Mode: ', 'eOpenReqHB'];...
% ['Valve Mode Code: ',                                                       'nValveModeId'];...
% ['Oil temperature in HPC: ',                                                'wOilTemp']
% };

outputVar1 = cell(numOfOutputVar,1);
for i = 1:numOfOutputVar
    outputVar1{i} = [outputVar(i).signalName];
end
% outputVar1 = {
% 'rpm';
% 'wOilTemp';  
% 'wCoilTemp';  
% 'eStart'; 
% 'eFinish';                    
% 'tSwOnMeas';
% 'tSwOnSVSXCylCL*';
% 'tSwOnLowPrec*';   
% 'tSwOffMeas';
% 'tSwOffSVSXCylCL*';
% 'tSwOnLowPrecV*';
% 'Current'
% };

specialCalibration = {
    'No', 'Calbration label', 'Value(s)', 'Note';
    '1',  '', '', '';
    '2',  '', '', '';
    '3',  '', '', '';
    '4',  '', '', ''
    '5',  '', '', ''
    '6',  '', '', ''
    '7',  '', '', ''
    '8',  '', '', ''
    '9',  '', '', ''
    };

% initialize abnormality collection

inputAbnormal       = cell(1,1);
inputAbnormalCnt    = 1;
inputAbnormal{1,1}  = 'Signal';
inputAbnormal{1,2}  = 'Maximum(rel)';
inputAbnormal{1,3}  = 'Minimum(rel)';
inputAbnormal{1,4}  = 'STD';
inputAbnormal{1,5}  = 'Mean';

% initialize abnormality collection

outputAbnormal      = cell(1,1);
outputAbnormalCnt   = 1;
outputAbnormal{1,1} = 'Signal';
outputAbnormal{1,2} = 'Maximum(rel)';
outputAbnormal{1,3} = 'Minimum(rel)';
outputAbnormal{1,4} = 'STD';
outputAbnormal{1,5} = 'Mean';

% initialize abnormality collection

currentAbnormal      = cell(1,1);
currentAbnormalCnt   = 1;
currentAbnormal{1,1} = 'Signal';
currentAbnormal{1,2} = 'Maximum(rel)';
currentAbnormal{1,3} = 'Minimum(rel)';
currentAbnormal{1,4} = 'STD';
currentAbnormal{1,5} = 'Mean';


