% generate plots and table for input check

clf;
pos = get(gcf,'Position');
set(gcf, 'Position',[pos(1) pos(2) 560 420]);

subplot(2,1,1);

doStairs = ~isempty(strfind(upper(inputVar(RegressionInputVar_INDEX).signalName),'TSWO'))    || ...
           ~isempty(strfind(upper(inputVar(RegressionInputVar_INDEX).signalName),'NVALVE'))  || ...
           ~isempty(strfind(upper(inputVar(RegressionInputVar_INDEX).signalName),'NABSCYL')) || ...
           ~isempty(strfind(upper(inputVar(RegressionInputVar_INDEX).signalName),'NACTREQ'));

if doStairs,
   stairs(inputVar(RegressionInputVar_INDEX).time, inputVar(RegressionInputVar_INDEX).signals(:,1),'b-');
   hold('on');
   stairs(inputVar(RegressionInputVar_INDEX).time, inputVar(RegressionInputVar_INDEX).signals(:,2),'r-');
else
   plot(inputVar(RegressionInputVar_INDEX).time, inputVar(RegressionInputVar_INDEX).signals(:,1),'b-');
   hold('on');
   plot(inputVar(RegressionInputVar_INDEX).time, inputVar(RegressionInputVar_INDEX).signals(:,2),'r-');
end

grid('on');
xlabel('(a)');
ylabel(inputVar(RegressionInputVar_INDEX).signalName);
updateYLimit(gca);

subplot(2,1,2);
if doStairs,
   stairs(inputVar(RegressionInputVar_INDEX).time, inputVar(RegressionInputVar_INDEX).signals(:,2)-inputVar(RegressionInputVar_INDEX).signals(:,1),'k-');
else
   plot(inputVar(RegressionInputVar_INDEX).time, inputVar(RegressionInputVar_INDEX).signals(:,2)-inputVar(RegressionInputVar_INDEX).signals(:,1),'k-');
end

grid('on');
xlabel({'time [ms]';'(b)'});
ylabel(['Difference for ', inputVar(RegressionInputVar_INDEX).signalName]);
set(gcf, 'Color',[1 1 1]);
updateYLimit(gca);

% make some statistics for the difference

[maxValue maxIndex] = max(inputVar(RegressionInputVar_INDEX).signals(:,2)-inputVar(RegressionInputVar_INDEX).signals(:,1));
[minValue minIndex] = min(inputVar(RegressionInputVar_INDEX).signals(:,2)-inputVar(RegressionInputVar_INDEX).signals(:,1));
meanValue           = mean(inputVar(RegressionInputVar_INDEX).signals(:,2)-inputVar(RegressionInputVar_INDEX).signals(:,1));
stdValue            = std(inputVar(RegressionInputVar_INDEX).signals(:,2)-inputVar(RegressionInputVar_INDEX).signals(:,1));
if inputVar(RegressionInputVar_INDEX).signals(maxIndex,1)~=0,
   diffRelMax       = maxValue/abs(inputVar(RegressionInputVar_INDEX).signals(maxIndex,1));
else
   diffRelMax       = maxValue;
end
if inputVar(RegressionInputVar_INDEX).signals(minIndex,1)~=0,
   diffRelMin       = minValue/abs(inputVar(RegressionInputVar_INDEX).signals(minIndex,1));
else
   diffRelMin       = minValue;
end

% collect bad cases

if abs(diffRelMin)>0.1 || abs(diffRelMax)>0.1,
   inputAbnormalCnt                  = inputAbnormalCnt + 1;
   inputAbnormal{inputAbnormalCnt,1} = inputVar(RegressionInputVar_INDEX).signalName;
   inputAbnormal{inputAbnormalCnt,2} = num2str(diffRelMax);
   inputAbnormal{inputAbnormalCnt,3} = num2str(diffRelMin);
   inputAbnormal{inputAbnormalCnt,4} = num2str(stdValue);
   inputAbnormal{inputAbnormalCnt,5} = num2str(meanValue);
end

table_data={};

table_data{2,1} = 'Diff(abs)';
table_data{3,1} = 'Diff(rel)';

table_data{1,2} = 'Maximum/Time';
table_data{2,2} = [num2str(maxValue),'/',num2str(inputVar(RegressionInputVar_INDEX).time(maxIndex))];
table_data{3,2} = diffRelMax;

table_data{1,3} = 'Minimum/Time';
table_data{2,3} = [num2str(minValue),'/',num2str(inputVar(RegressionInputVar_INDEX).time(minIndex))];
table_data{3,3} = diffRelMin;

table_data{1,4} = 'STD';
table_data{2,4} = num2str(stdValue);

table_data{1,5} = 'Mean';
table_data{2,5} = num2str(meanValue);

%table_data{1,6} = 'Note';
%table_data{2,6} = '';

