 % generate plots for vars from original drivng sequence 

clf;
subplot(1,1,1);

doStairs = ~isempty(strfind(upper(inputVar(drivingSeqInputVar_INDEX).signalName),'TSWO'))    || ...
           ~isempty(strfind(upper(inputVar(drivingSeqInputVar_INDEX).signalName),'NVALVE'))  || ...
           ~isempty(strfind(upper(inputVar(drivingSeqInputVar_INDEX).signalName),'NABSCYL')) || ...
           ~isempty(strfind(upper(inputVar(drivingSeqInputVar_INDEX).signalName),'NACTREQ'));

if doStairs,
   stairs(inputVar(drivingSeqInputVar_INDEX).time, inputVar(drivingSeqInputVar_INDEX).signals(:,1),'b-');
else
   plot(inputVar(drivingSeqInputVar_INDEX).time, inputVar(drivingSeqInputVar_INDEX).signals(:,1),'b-');
end

grid('on');
xlabel('time [ms]');
ylabel(inputVar(drivingSeqInputVar_INDEX).signalName);
pos = get(gcf,'Position');
set(gcf, 'Position',[pos(1) pos(2) 560 420*0.7]);
updateYLimit(gca);


