% initialize and prepare current data

currentLastRelease    = evalin('base', 'currentLastRelease');
currentCurrentRelease = evalin('base', 'currentCurrentRelease');
 
myMdfImport(currentLastRelease, 'workspace');

current          = struct('signalName',{}, 'signals',{}, 'time',{});

chnNo1           = '1';
chnNo2           = '2';
chnNo3           = '4';

current(1).signalName   = 'Current1';
current(1).description  = 'Current for SV in clyinder 1';
current(1).signals(:,1) = eval(['[evalin(''base'',', '''Current_10_',   chnNo1,''')]']);
current(1).time         = eval(['[evalin(''base'',', '''time_',         chnNo1,''')]']);

current(2).signalName   = 'Current2';
current(2).description  = 'Current for SV in clyinder 2';
current(2).signals(:,1) = eval(['[evalin(''base'',', '''Current_20_',   chnNo1,''')]']);
current(2).time         = eval(['[evalin(''base'',', '''time_',         chnNo1,''')]']);

current(3).signalName   = 'Current3';
current(3).description  = 'Current for SV in clyinder 3';
current(3).signals(:,1) = eval(['[evalin(''base'',', '''Current_30_',   chnNo1,''')]']);
current(3).time         = eval(['[evalin(''base'',', '''time_',         chnNo1,''')]']);

current(4).signalName   = 'Current4';
current(4).description  = 'Current for SV in clyinder 4';
current(4).signals(:,1) = eval(['[evalin(''base'',', '''Current_40_',   chnNo1,''')]']);
current(4).time         = eval(['[evalin(''base'',', '''time_',         chnNo1,''')]']);

% myBreak;

% clear the vars just read 
clear('-regexp', '_');

numOfCurrent = length(current);

myMdfImport(currentCurrentRelease, 'workspace');

timeCorrection = 0;

timei                   = eval(['[evalin(''base'',', '''time_',            chnNo1,''')]']);
currenti                = eval(['[evalin(''base'',', '''Current_10_',      chnNo1,''')]']);

% timeCorrection = getSignalShift([inputVar(1).time,inputVar(1).signals(:,1)], [timei, inputVari]);

current(1).signals(:,2) = interp1(timei+timeCorrection, currenti, current(1).time);

currenti                = eval(['[evalin(''base'',', '''Current_20_',      chnNo1,''')]']);
current(2).signals(:,2) = interp1(timei+timeCorrection, currenti, current(2).time);

currenti                = eval(['[evalin(''base'',', '''Current_30_',      chnNo1,''')]']);
current(3).signals(:,2) = interp1(timei+timeCorrection, currenti, current(3).time);

currenti                = eval(['[evalin(''base'',', '''Current_40_',      chnNo1,''')]']);
current(4).signals(:,2) = interp1(timei+timeCorrection, currenti, current(4).time);

% make some arbitary shift
if 1,
   current(1).signals(2:end,2) = current(1).signals(1:end-1,2);
   current(2).signals(2:end,2) = current(2).signals(1:end-1,2);
   current(3).signals(2:end,2) = current(3).signals(1:end-1,2);
   current(4).signals(2:end,2) = current(4).signals(1:end-1,2);
end

clear('-regexp', '_');
